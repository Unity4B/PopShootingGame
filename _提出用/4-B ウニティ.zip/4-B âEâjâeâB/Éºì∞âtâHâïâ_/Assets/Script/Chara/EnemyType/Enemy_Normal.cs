﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Normal : MonoBehaviour
{
    public int HP;
    public float movespeed;
    public int Power;
    public float HitPower;

    void Start()
    {
        movespeed = movespeed * 0.01f;//100分の1倍
    }
    public int enemyHP()
    {
        return HP;
    }
    public float moveSpeed()
    {
        return movespeed;
    }
    public int damege()
    {
        return Power;
    }
    public float knockback()
    {
        return HitPower;
    }
}
