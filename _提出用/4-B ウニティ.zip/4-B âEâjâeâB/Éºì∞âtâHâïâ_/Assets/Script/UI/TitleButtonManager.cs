﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TitleButtonManager : MonoBehaviour
{
    public GameObject optionCanvas, weaponSelectCanvas;

    // Start is called before the first frame update
    void Start()
    {
        optionCanvas.SetActive(false);
        weaponSelectCanvas.SetActive(false);
    }

    public void OnbuttonDown_Start()
    {
        optionCanvas.SetActive(true);
    }
    public void OnbuttonDown_Exit()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#elif UNITY_STANDALONE
             UnityEngine.Application.Quit();
#endif
    }
}
