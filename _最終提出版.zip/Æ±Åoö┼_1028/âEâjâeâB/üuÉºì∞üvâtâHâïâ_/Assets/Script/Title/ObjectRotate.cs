﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// オブジェクトを回転させる
/// </summary>
public class ObjectRotate : MonoBehaviour
{
	/// <summary>
	/// 回転軸
	/// </summary>
	public enum RotateType { X, Y, Z }

	//フィールド
	/// <summary>
	/// １フレームでの回転量
	/// </summary>
	[SerializeField] float speed = 1.0f;
	/// <summary>
	/// 回転タイプ
	/// </summary>
	[SerializeField] RotateType rType = RotateType.X;

	void Update()
	{
		switch (this.rType)
		{
			case RotateType.X: transform.Rotate(new Vector3(this.speed, 0.0f, 0.0f)); break;
			case RotateType.Y: transform.Rotate(new Vector3(0.0f, this.speed, 0.0f)); break;
			case RotateType.Z: transform.Rotate(new Vector3(0.0f, 0.0f, this.speed)); break;
		}

	}
}
