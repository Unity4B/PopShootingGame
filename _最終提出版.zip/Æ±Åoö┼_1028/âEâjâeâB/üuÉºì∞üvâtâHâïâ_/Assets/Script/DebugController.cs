﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// デバック操作
/// </summary>
public class DebugController : MonoBehaviour
{
	/// <summary>
	/// デバックON:OFFキー
	/// </summary>
	[SerializeField] KeyCode key = KeyCode.None;
	/// <summary>
	/// デバックオブジェクト
	/// </summary>
	[SerializeField] GameObject[] debugObjs = null;
	/// <summary>
	/// 有効・無効か
	/// </summary>
	bool isActive;
	//------------------------------------------------------
	void Awake()
	{
		if (GameObject.FindObjectsOfType<DebugController>().Length > 1)
		{
			Destroy(gameObject);
		}
		else
		{
			DontDestroyOnLoad(gameObject);
		}
	}
	//------------------------------------------------------
	void Start()
	{
		this.isActive = true;
		DebugActive();
	}
	//------------------------------------------------------
	void Update()
	{
		if (Input.GetKeyDown(this.key)) { DebugActive(); }
	}
	//------------------------------------------------------
	/// <summary>
	/// デバック有効・無効化
	/// </summary>
	public void DebugActive()
	{
		this.isActive = (!this.isActive);
		foreach (GameObject obj in this.debugObjs)
		{
			obj.SetActive(this.isActive);
		}
	}
	//------------------------------------------------------
}
