﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

//-------------------------------------------------
/// <summary>
/// UI:リザルト
/// </summary>
public class ResultManager : MonoBehaviour
{
    //フィールド
    /// <summary>
    /// ウェーブ数表示テキスト
    /// </summary>
    [SerializeField] Text waveText = null;
    /// <summary>
    /// スコア表示テキスト
    /// </summary>
    [SerializeField] Text scoreText = null;
    /// <summary>
    /// SEクラス
    /// </summary>
    [SerializeField] AudioSE seClass = null;
    /// <summary>
    /// シーンの管理
    /// </summary>
    [SerializeField] SceneChangeController sceneClass = null;
    //-------------------------------------------------
    void Start()
    {
        DisplayText();
    }

    //-------------------------------------------------
    /// <summary>
    /// リトライボタンクリック時の処理
    /// </summary>
    public void OnbuttonDown_Retry()
    {
        this.seClass.AudioSESet(1, 0.5f);

        this.sceneClass.SceneChange(SceneManager.GetActiveScene().name);
    }

    /// <summary>
    /// 終了ボタンクリック時の処理
    /// </summary>
    public void OnbuttonDown_Exit()
    {
        this.seClass.AudioSESet(1, 0.5f);

        //タイトル画面へ
        this.sceneClass.SceneChange("TitleScene");
    }
    //-------------------------------------------------
    /// <summary>
    /// 結果表示
    /// </summary>
    void DisplayText()
    {
        this.scoreText.text = "SCORE:" + GameManager.score.ToString("D4");
        this.waveText.text = "WAVE:" + GameManager.waveNowCnt;
    }
}
