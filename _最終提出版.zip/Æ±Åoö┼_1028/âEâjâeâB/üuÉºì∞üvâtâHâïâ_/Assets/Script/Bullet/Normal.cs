﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Normal : Bullet
{
    public Normal() : base(BulletType.Normal) { }

    public override void Update()
    {
        base.Update();
    }

    //敵との当たり判定処理
    public override void Damage(Collider target)
    {
        //Bulletクラスの処理(共通)
        base.Damage(target);
        //通常弾独自処理
        Destroy(gameObject);
        Debug.Log("通常ダメージ！");
    }
}