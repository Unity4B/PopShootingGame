﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------
/// <summary>
/// UI:Wave表示テキスト
/// </summary>
public class WaveTextController : MonoBehaviour
{
    //フィールド
    /// <summary>
    /// ウェーブ数表示テキスト
    /// </summary>
    [SerializeField] Text wText = null;
    /// <summary>
    /// 前フレームのウェーブ数
    /// </summary>
    int preWaveCnt;
    //-------------------------------------------------
    void Start()
    {
        //更新
        InfoUpdate();
    }

    void Update()
    {
        //変更されていればUIに反映
        if (CheckWaveChange())
		{
            //更新
            InfoUpdate();
        }
    }
    //-------------------------------------------------
    /// <summary>
    /// ウェーブが変わったかチェック
    /// </summary>
    /// <returns></returns>
    bool CheckWaveChange()
	{
        return GameManager.waveNowCnt != preWaveCnt;
	}
    //-------------------------------------------------
    /// <summary>
    /// 情報更新
    /// </summary>
    void InfoUpdate()
	{
        //更新
        this.wText.text = "WAVE:" + GameManager.waveNowCnt.ToString();

        this.preWaveCnt = GameManager.waveNowCnt;
    }
}
