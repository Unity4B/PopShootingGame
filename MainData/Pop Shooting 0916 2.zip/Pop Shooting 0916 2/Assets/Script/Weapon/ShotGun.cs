﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// ショットガン
/// </summary>
public class ShotGun : Weapon
{
    //-------------------------------------------------
    void Start()
    {
        this.wData.SetWeaponType(WeaponType.ShotGun);
    }

    //-------------------------------------------------
    public override void Shot()
    {
        //射撃間隔を確認
        if (this.wData.deltaTime >= this.wData.interval)
        {
            //マウス入力状態に応じて
            if (ScreenTouch.touchState == TouchPhase.Began)
            {
                Vector2 preAngle = new Vector2(0.0f,0.0f);

                for (int i = 0; i < 4; i++)
                {
                    //発射角をランダムに
                    Vector2 sAngle  = new Vector2(Random.Range(-10.0f,10.0f),Random.Range(-10.0f,10.0f));
                    sAngle -= preAngle;

                    //回転
                    transform.Rotate(sAngle.x, sAngle.y, 0.0f);
                    //弾生成
                    BulletGenerate();

                    preAngle = sAngle;
                }
                //元に戻す
                Vector3 angle = transform.parent.rotation.eulerAngles - transform.rotation.eulerAngles;
                transform.Rotate(angle);
            }

            this.wData.deltaTime = 0.0f;
        }
        else
        {
            this.wData.deltaTime += Time.deltaTime;
        }
    }
    //-------------------------------------------------
}
