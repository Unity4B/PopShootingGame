﻿using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum BulletType
{
    Normal,     //通常弾
    Pierce,     //貫通弾
    Explosive,  //爆発弾
}

public class Bullet : MonoBehaviour
{
    BulletType bulletType;  //種類
    public int bPower; //威力
    public float bSpeed;    //スピード

    private Vector3 playerPos;   
    private float distance;

    public new MeshRenderer renderer;
    private ParticleGenerator pg;

    //弾の威力とスピード設定
    public Bullet(BulletType bulletType_)
    {
        this.bulletType = bulletType_;

        switch (this.bulletType)
        {
            case BulletType.Normal:
                {
                    this.bPower = 1;
                    this.bSpeed = 20.0f;
                    break;
                }
            case BulletType.Pierce:
                {
                    this.bPower = 1;
                    this.bSpeed = 20.0f;
                    break;
                }
            case BulletType.Explosive:
                {
                    this.bPower = 1;
                    this.bSpeed = 20.0f;
                    break;
                }
        }
    }

    public virtual void Start()
    {
        renderer = GetComponentInChildren<MeshRenderer>();
        pg = GameObject.Find("Generator").GetComponent<ParticleGenerator>();
    }

    public virtual void Update()
    {
        Shoot(this.bSpeed);
        SetDistance();

        //プレイヤーと一定距離離れたら(マップの外に出たら)消去
        if (distance > 75.0f)
        {
            Destroy(gameObject);
        }
    }

    //弾の発射メソッド
    public void Shoot(float bSpeed_)
    {
        this.transform.position += transform.forward * bSpeed_ * Time.deltaTime;
    }

    private void OnTriggerEnter(Collider target)
    {   
        if (target.gameObject.tag == "Enemy")
        {
            Damage(target);
        }
    }

    //敵との当たり判定処理(弾ごと追加処理があれば各弾のクラスで追記)
    public virtual void Damage(Collider target)
    {
        target.gameObject.GetComponent<Enemy>().Hit(bPower); //HP判定処理
        pg.Damaged(transform.position);
    }


    public void SetDistance()
    {
        playerPos = GameObject.FindGameObjectWithTag("Player").transform.position; //プレイヤの位置
        distance = Vector3.Distance(transform.position, playerPos);   //自分の位置からプレイヤー位置までの距離
    }
}