﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------
/// <summary>
/// 武器生成
/// </summary>
public class WeaponGenerator : MonoBehaviour
{
	//フィールド
	/// <summary>
	/// 装備する武器タイプを格納
	/// </summary>
	public static WeaponData[] weaponDatas = new WeaponData[2];
	/// <summary>
	/// 生成する武器オブジェクト
	/// </summary>
	[SerializeField] GameObject[] weaponObjs = new GameObject[]{ };
	/// <summary>
	/// 親となるオブジェクト
	/// </summary>
	[SerializeField] GameObject parent = null;
	//-------------------------------------------------
	void Awake()
	{
		//親オブジェクトがない場合、処理せず
		if(this.parent == null) { return; }

		for(int i = 0; i < weaponDatas.Length;i++)
		{
			//武器生成
			Instantiate<GameObject>(this.weaponObjs[(int)weaponDatas[i].WType], this.parent.transform);
		}
	}
	//-------------------------------------------------
}
