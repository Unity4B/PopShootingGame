﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// エネミーオブジェクト管理
/// </summary>
public class EnemyManager : MonoBehaviour
{
    /// <summary>
    /// 存在するエネミー
    /// </summary>
    public List<GameObject> enemys;

    void Start()
    {
        this.enemys = new List<GameObject>();

    }

    void Update()
    {
        for(int i = 0; i < this.enemys.Count;i++)
		{
            if(this.enemys[i] == null) { this.enemys.RemoveAt(i); }
		}
    }
}
