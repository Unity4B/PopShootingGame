﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------
/// <summary>
/// タイトルシーン統括
/// </summary>
public class TitleManager : MonoBehaviour
{
    //フィールド
    [SerializeField] AudioBGM bgmClass = null;
    //-------------------------------------------------
    void Awake()
    {
        //武器生成情報初期化
        for(int i = 0; i < WeaponGenerator.weaponDatas.Length; i++ )
		{
            WeaponGenerator.weaponDatas[i] = new WeaponData();
		}
        
    }

    void Start()
    {
        //BGM再生
        this.bgmClass.AudioBGMSet(0, 0.2f);
    }

	void Update()
	{
		if(Input.GetKeyDown(KeyCode.Escape))
		{
            Application.Quit();
		}
	}
	//-------------------------------------------------
}
