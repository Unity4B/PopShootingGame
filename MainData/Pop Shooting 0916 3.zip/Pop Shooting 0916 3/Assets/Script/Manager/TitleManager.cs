﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------
/// <summary>
/// タイトルシーン統括
/// </summary>
public class TitleManager : MonoBehaviour
{
    //フィールド
    //-------------------------------------------------
    void Start()
    {
        //BGM再生

    }

    void Update()
    {
        
    }
    //-------------------------------------------------
}
