﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------
/// <summary>
/// ゲームシーン統括
/// </summary>
public class GameManager : MonoBehaviour
{
    //フィールド
    /// <summary>
    /// 現在のウェーブ数
    /// </summary>
    public static int waveNowCnt;
    /// <summary>
    /// ゲームスコア
    /// </summary>
    public static int score;
    /// <summary>
    /// ウェーブ切り替えのフレーム数
    /// </summary>
    [SerializeField] int limitFrameCnt = 3000;
    /// <summary>
    /// 経過フレーム数
    /// </summary>
    int frameCnt;
    /// <summary>
    /// BGMクラス
    /// </summary>
    [SerializeField] AudioBGM bgmClass = null;
	//-------------------------------------------------
	void Awake()
	{
        //ウェーブ初期化
        waveNowCnt = 0;

        score = 0;

        this.frameCnt = 0;
	}

	void Start()
    {
        this.bgmClass.AudioBGMSet(1, 0.2f);
    }

    void Update()
    {

        WaveCount();
    }
    //-------------------------------------------------
    /// <summary>
    /// ウェーブカウント
    /// </summary>
    void WaveCount()
	{
        if(this.frameCnt >= this.limitFrameCnt) 
        {
            //ウェーブチェンジ
            waveNowCnt++;

            //カウントリセット
            this.frameCnt = 0;
        }
        else
		{
            //カウント
            this.frameCnt++;
		}
	}
}
