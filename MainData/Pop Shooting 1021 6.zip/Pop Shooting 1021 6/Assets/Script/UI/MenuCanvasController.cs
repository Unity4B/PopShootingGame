﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// UI:メニュー操作
/// </summary>
public class MenuCanvasController : MonoBehaviour
{
    //フィールド
    /// <summary>
    /// SEクラス
    /// </summary>
    [SerializeField] AudioSE seClass = null;
    /// <summary>
    /// 武器選択画面生成クラス
    /// </summary>
    [SerializeField] WeaponSelectGenerator weaponSelectGenerator = null;
    //-------------------------------------------------
    //メニューで使用するボタンの処理
    //-------------------------------------------------
    /// <summary>
    /// リトライ処理
    /// </summary>
    public void Retry()
	{
        //SE
        this.seClass.AudioSESet(1, 0.5f);
        //生成
        this.weaponSelectGenerator.WeaponSelectGenerate();


	}
    //-------------------------------------------------
    /// <summary>
    /// ゲーム強制終了処理
    /// </summary>
    public void GameEscape()
	{
        //SE
        this.seClass.AudioSESet(1, 0.5f);
        Application.Quit();
	}
    //-------------------------------------------------
    /// <summary>
    /// メニューの表示・非表示
    /// </summary>
    /// <param name="isActive">表示か</param>
    public void MenuActive(bool isActive)
	{
        //モード：ゲーム終了の場合、処理せず
        if(GameManager.mode == GameMode.End) { return; }

        //SE
        this.seClass.AudioSESet(1, 0.5f);

        //モードチェンジ
        if (isActive)   { GameManager.mode = GameMode.Menu; }
		else            { GameManager.mode = GameMode.InGame; }

        gameObject.SetActive(isActive);
	}
    //-------------------------------------------------
}
