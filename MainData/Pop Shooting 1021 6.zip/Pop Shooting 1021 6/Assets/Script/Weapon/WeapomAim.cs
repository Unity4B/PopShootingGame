﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------
/// <summary>
/// 武器の照準表示
/// </summary>
public class WeapomAim : MonoBehaviour
{
    //フィールド
    /// <summary>
    /// 参照対象
    /// </summary>
    [SerializeField] Player player = null;
    /// <summary>
    /// 武器の親オブジェクト
    /// </summary>
    [SerializeField] GameObject weaponParent = null;
    //-------------------------------------------------
    void Update()
    {
        GameObject go = this.weaponParent.transform.GetChild(this.player.weaponNum).gameObject;
        Vector3 pos = go.transform.position + (go.transform.forward * 40.0f);

        transform.position = Camera.main.WorldToScreenPoint(pos);

        //カメラの向きにプレイヤーの向きを合わせる
        //float y = Camera.main.transform.rotation.eulerAngles.y - transform.rotation.eulerAngles.y;
        //transform.Rotate(new Vector3(0.0f, y, 0.0f), Space.World);
    }
    //-------------------------------------------------
}
