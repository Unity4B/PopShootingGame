﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Explosive : Bullet
{
    public Explosive() : base(BulletType.Explosive) { }

    private GameObject bulletArea;
    private SphereCollider bombArea;

    public override void Start()
    {
        bulletArea = transform.GetChild(0).gameObject;
        bulletArea.SetActive(false);
        bombArea = bulletArea.GetComponent<SphereCollider>();
    }

    private void OnTriggerEnter(Collider target)
    {
        if (target.gameObject.tag == "Enemy")
        {
            Debug.Log("爆発！");
            bulletArea.SetActive(true);
            target.gameObject.SetActive(false);
            renderer.enabled = false;
        }
    }
}
