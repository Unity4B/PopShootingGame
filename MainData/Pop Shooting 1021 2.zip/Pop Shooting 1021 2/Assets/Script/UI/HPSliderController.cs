﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------
/// <summary>
/// UI:プレイヤーHPスライダー
/// </summary>
public class HPSliderController : MonoBehaviour
{
	//フィールド
	/// <summary>
	/// HP表示スライダー
	/// </summary>
	[SerializeField] Slider hpSlider = null;
	/// <summary>
	/// プレイヤークラス
	/// </summary>
	[SerializeField] Player player = null;
	/// <summary>
	/// 前の体力値
	/// </summary>
	int preLife;
	//-------------------------------------------------
	void Start()
	{
		this.hpSlider.maxValue	= this.player.charaParam.maxlife;
		this.hpSlider.value		= this.player.charaParam.life;
	}

	void Update()
	{
		//変更されていればUIに反映
		if (CheckLifeChange())
		{
			InfoUpdate();
		}
	}
	//-------------------------------------------------
	/// <summary>
	/// 前フレームと比較して体力が変わっているかチェック
	/// </summary>
	/// <returns></returns>
	bool CheckLifeChange()
	{
		return this.player.charaParam.life != this.preLife;
	}
	//-------------------------------------------------
	/// <summary>
	/// 情報更新
	/// </summary>
	void InfoUpdate()
	{
		//更新
		this.hpSlider.value = this.player.charaParam.life;

		this.preLife = this.player.charaParam.life;
	}
}
