﻿using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------
/// <summary>
/// ハンドガン
/// </summary>
public class HundGun : Weapon
{
	//-------------------------------------------------
	void Start()
    {
		this.wData.SetWeaponType(WeaponType.HundGun);

	}

	void Update()
    {
        
    }

	//-------------------------------------------------
	//射撃処理
	public override void Shot()
	{
		//マウス入力状態に応じて
		if (ScreenTouch.touchState == TouchPhase.Began)
		{
			BulletGenerate();
			//SE
			this.seClass.AudioSESet(4, 0.4f);
		}

	}
	//-------------------------------------------------
}
