﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------
/// <summary>
/// UI:装備中の武器情報表示
/// </summary>
public class WeaponInfoController : MonoBehaviour
{
    //フィールド
    /// <summary>
    /// 表示画像
    /// </summary>
    [SerializeField] Image  wImage = null;
    /// <summary>
    /// 表示テキスト
    /// </summary>
    [SerializeField] Text   wText = null;
    /// <summary>
    /// プレイヤークラス
    /// </summary>
    [SerializeField] Player player = null;
    /// <summary>
    /// 前フレームの武器種
    /// </summary>
    WeaponType       prewType;
    /// <summary>
    /// 表示する武器画像
    /// </summary>
    [SerializeField] Sprite[] sprites = null;
    //-------------------------------------------------
    void Start()
    {
        this.prewType   = WeaponType.None;
    }

    void Update()
    {
        //変更されていればUIに反映
        if(Check_ChangeWeapon())
		{
            InfoUpdate();
		}

    }
    //-------------------------------------------------
    /// <summary>
    /// 前フレームと比較して武器が変更されているか確認
    /// </summary>
    /// <returns></returns>
    bool Check_ChangeWeapon()
	{
        return this.player.weapon.wData.WType != this.prewType;
	}
    //-------------------------------------------------
    /// <summary>
    /// 情報更新
    /// </summary>
    void InfoUpdate()
	{
        //画像更新
        this.wImage.sprite  = this.sprites[(int)this.player.weapon.wData.WType];
        //テキスト更新
        this.wText.text     = this.player.weapon.wData.WName;

        this.prewType       = this.player.weapon.wData.WType;

    }
}
