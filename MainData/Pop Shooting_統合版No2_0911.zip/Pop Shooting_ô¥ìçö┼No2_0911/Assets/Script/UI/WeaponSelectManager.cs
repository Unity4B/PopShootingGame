﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WeaponSelectManager : MonoBehaviour
{
    public GameObject optionCanvas;
    public OptionManager optionManager;
    public Text weaponText;

    // Start is called before the first frame update
    void Start()
    {
        optionCanvas = GameObject.Find("WeaponSelect").transform.Find("OptionCanvas").gameObject;
        optionManager = optionCanvas.GetComponent<OptionManager>();
    }

    public void OnbuttonDown_HandGun()
    {
        optionCanvas.SetActive(true);
        optionManager.clickButton.GetComponentInChildren<Text>().text = "ハンドガン";
        gameObject.SetActive(false);
    }
    public void OnbuttonDown_ShotGun()
    {
        optionCanvas.SetActive(true);
        optionManager.clickButton.GetComponentInChildren<Text>().text = "ショットガン";
        gameObject.SetActive(false);
    }
    public void OnbuttonDown_AssaultGun()
    {
        optionCanvas.SetActive(true);
        optionManager.clickButton.GetComponentInChildren<Text>().text = "ハンドガン";
        gameObject.SetActive(false);
    }
    public void OnbuttonDown_RocketLauncher()
    {
        optionCanvas.SetActive(true);
        optionManager.clickButton.GetComponentInChildren<Text>().text = "ロケットランチャー";
        gameObject.SetActive(false);
    }
    public void OnbuttonDown_Sniper()
    {
        optionCanvas.SetActive(true);
        optionManager.clickButton.GetComponentInChildren<Text>().text = "スナイパー";
        gameObject.SetActive(false);
    }
    public void OnbuttonDown_Exit()
    {
        optionCanvas.SetActive(true);
        gameObject.SetActive(false);
    }
}
