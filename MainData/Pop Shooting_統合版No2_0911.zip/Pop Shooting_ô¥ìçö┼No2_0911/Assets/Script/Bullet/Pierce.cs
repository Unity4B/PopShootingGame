﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pierce : Bullet
{
    public Pierce() : base(BulletType.Pierce) { }

	new MeshRenderer renderer;

	public override void Start()
	{
		renderer = GetComponent<MeshRenderer>();
	}

	public override void Update()
	{
		if(!renderer.isVisible)	//画面内にいないなら
		{
			this.gameObject.SetActive(false);
		}
	}
	private void OnTriggerEnter(Collider target)
    {
		if (target.gameObject.tag == "Enemy")
		{
			Debug.Log("貫通ダメージ！");
			target.gameObject.SetActive(false);
		}
	}
}
