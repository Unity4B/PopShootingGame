﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Weapon : MonoBehaviour
{
    //武器種
    public enum WeaponType
	{
        None        = -1,
        HundGun     = 0,
        AssaultGun  = 1,
        
	}

    //武器データ
    [System.Serializable]
    public struct WeaponData
	{
        public WeaponType   wType;      //武器の種類
        public GameObject   bullet;     //弾の種類
        public float        interval;   //射撃間隔
        public float        deltaTime;  //射撃間隔カウンタ

	}
    public WeaponData wData;

    public void BulletGenerate()
	{
        GameObject bullet_          = Instantiate<GameObject>(this.wData.bullet);
        bullet_.transform.position  = transform.position;
        bullet_.transform.rotation  = transform.rotation;
	}

    //射撃処理
    public abstract void Shot();
}
