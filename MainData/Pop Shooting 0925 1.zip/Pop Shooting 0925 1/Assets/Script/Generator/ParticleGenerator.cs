﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParticleGenerator : MonoBehaviour
{
    public GameObject damagedParticle; //爆発エフェクト
    public GameObject rippleParticle; //波紋エフェクト
    public GameObject smokeParticle;   //煙エフェクト
    /// <summary>
    /// パーティクル生成用キャンバス
    /// 柄子
    /// </summary>
    [SerializeField] Canvas particleCanvas = null;

    //爆発エフェクト生成
    public void Damaged(Vector3 pos_)
    {
        Instantiate(damagedParticle, pos_, Quaternion.identity);
    }

    //波紋エフェクト生成(UI)
    public void Ripple(Vector3 pos_)
    {
        GameObject go = Instantiate(rippleParticle, this.particleCanvas.transform);
        go.transform.position = ScreenTouch.touchPos;
    }

    //煙エフェクト生成
    public void Smoke(Vector3 pos_)
    {
        Instantiate(smokeParticle, pos_, Quaternion.identity);
    }
}
