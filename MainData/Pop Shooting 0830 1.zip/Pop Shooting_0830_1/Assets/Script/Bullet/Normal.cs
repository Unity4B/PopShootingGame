﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Normal : Bullet
{
    public Normal() : base(BulletType.Normal) { }

    private void OnTriggerEnter(Collider target)
    {
        if (target.gameObject.tag == "Enemy")
        {
            this.gameObject.SetActive(false);
            Debug.Log("通常ダメージ！");
            target.gameObject.SetActive(false);
        }
    }
}
