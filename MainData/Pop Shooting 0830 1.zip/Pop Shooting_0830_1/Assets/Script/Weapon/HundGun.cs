﻿using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HundGun : Weapon
{
    void Start()
    {
		
    }

    void Update()
    {
        
    }

    //射撃処理
	public override void Shot()
	{
        //マウス入力時のみ処理
		if (!ScreenTouch.isTouch) { return; }
		//マウス入力状態に応じて
		if (ScreenTouch.touchState == TouchPhase.Began)
		{
			BulletGenerate();
		}

	}
}
