﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScreenTouch : MonoBehaviour
{
    public static bool          isTouch;
    public static TouchPhase    touchState;
    public static Vector3       touchPos;

    void Start()
    {
        
    }

    void Update()
    {
        ScreenTouch.isTouch = CheckTouch();
    }


    //タッチ関連の更新
    public bool CheckTouch()
    {
        bool isTouch = false;

        //エディター
        //if(Application.isEditor)
        {
            //押した瞬間
            if (Input.GetMouseButtonDown(0))
            {
                isTouch = true;
                ScreenTouch.touchState = TouchPhase.Began;
                Debug.Log("押した瞬間");
            }
            //離した瞬間
            else if (Input.GetMouseButtonUp(0))
            {
                isTouch = true;
                ScreenTouch.touchState = TouchPhase.Ended;
                Debug.Log("離した瞬間");
            }
            //押している間
            else if (Input.GetMouseButton(0))
            {
                isTouch = true;
                ScreenTouch.touchState = TouchPhase.Moved;
                Debug.Log("押している間");
            }

            //座標取得
            if (isTouch) { ScreenTouch.touchPos = Input.mousePosition; }
        }

        return isTouch;
    }
    //--------------------------------------------------------------------------

}
