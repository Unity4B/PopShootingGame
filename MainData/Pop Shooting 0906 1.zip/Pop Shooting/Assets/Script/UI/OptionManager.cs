﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class OptionManager : MonoBehaviour
{
    public GameObject weaponSelectCanvas;
    public GameObject start, exit, weapon1, weapon2, clickButton;   //clickButton以外はinspectorにアタッチさせる

    // Start is called before the first frame update
    void Start()
    {
        weaponSelectCanvas.SetActive(false);
    }
    
    public void OnbuttonDown_Start()
	{
        SceneManager.LoadScene("TestScene_0830");
	}
    public void OnbuttonDown_Exit()
    {
        weapon1.GetComponentInChildren<Text>().text = "武器１";
        weapon2.GetComponentInChildren<Text>().text = "武器２";
        gameObject.SetActive(false);
    }
    public void OnbuttonDown_Weapon1()
    {
        clickButton = weapon1;
        weaponSelectCanvas.SetActive(true);
        gameObject.SetActive(false);
    }
    public void OnbuttonDown_Weapon2()
    {
        clickButton = weapon2;
        weaponSelectCanvas.SetActive(true);
        gameObject.SetActive(false);
    }
}
