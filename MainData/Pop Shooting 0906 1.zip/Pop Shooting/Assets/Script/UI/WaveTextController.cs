﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//UI:Wave表示テキスト
public class WaveTextController : MonoBehaviour
{
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
