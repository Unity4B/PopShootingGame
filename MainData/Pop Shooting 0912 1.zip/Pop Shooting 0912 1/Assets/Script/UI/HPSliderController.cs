﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//UI:プレイヤーHPスライダー
public class HPSliderController : MonoBehaviour
{
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
