﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SubCameraMove : MonoBehaviour
{
    [SerializeField] private GameObject subCamera;              //メインカメラ格納用
    private Vector3 playerObject;  //回転の中心となるプレイヤー格納用
    private float speed;

    private Player player;

    void Start()
    {
        //初期化処理
        playerObject = GameObject.FindWithTag("Player").transform.position;//プレイヤ検索
        speed = 5.0f;
    }

    // Update is called once per frame
    void Update()
    {
        //ゲーム中のみ処理
        if (GameManager.mode != GameMode.InGame) { return; }

        rotateCamera();//カメラ回転関数
    }
    private void rotateCamera()
    {
        //Vector3でX,Y方向の回転の度合いを定義
        Vector3 angle = new Vector3(Input.GetAxis("Mouse X") * speed, 0, 0);
        subCamera.transform.RotateAround(playerObject, Vector3.up, angle.x);
    }
}
