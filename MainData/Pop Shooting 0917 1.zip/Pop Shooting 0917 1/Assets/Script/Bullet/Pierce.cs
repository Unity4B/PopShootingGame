﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pierce : Bullet
{
    public Pierce() : base(BulletType.Pierce) { }

	public override void Start()
	{
        base.Start();
	}

	public override void Update()
	{
        base.Update();
	}

    public override void Damage(Collider target)
    {
        base.Damage(target);

        Debug.Log("貫通ダメージ！");
    }
}
