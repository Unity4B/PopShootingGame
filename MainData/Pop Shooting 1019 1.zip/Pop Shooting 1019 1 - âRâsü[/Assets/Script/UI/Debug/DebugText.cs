﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DebugText : MonoBehaviour
{
    /// <summary>
    /// デバックテキスト
    /// </summary>
    [SerializeField] Text debugText = null;
    /// <summary>
    /// 表示するテキスト
    /// </summary>
    static string texts;
    /// <summary>
    /// 表示し続けるテキスト
    /// </summary>
    static string textContinues;
	//------------------------------------------------------
	void Awake()
	{
        DontDestroyOnLoad(gameObject);	
	}
	//------------------------------------------------------
	void Update()
    {
        //リセット
        this.debugText.text = "";
        DebugText.texts = "";

        //表示
        this.debugText.text += DebugText.textContinues;
        this.debugText.text += DebugText.texts;

    }
    //------------------------------------------------------
    /// <summary>
    /// デバックテキストに文字列追加
    /// </summary>
    /// <param name="msg">追加する文字列</param>
    public static void Log(string msg)
	{
        DebugText.texts += msg + "\n";
	}
    //------------------------------------------------------
    /// <summary>
    /// デバックテキストに文字列を追加(表示し続けるログ)
    /// </summary>
    /// <param name="msg">追加する文字列</param>
    public static void LogContinue(string msg)
	{
        DebugText.textContinues += msg + "\n";
	}
    //------------------------------------------------------

}
