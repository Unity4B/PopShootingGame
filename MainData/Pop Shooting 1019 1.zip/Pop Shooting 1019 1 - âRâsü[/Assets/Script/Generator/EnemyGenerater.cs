﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyGenerater : MonoBehaviour
{
    //ファイルから読み込む敵データ
    public struct EnemyData
	{
        public int SpawnRate;       //出現までのフレーム数
        public int EnemyType;       //敵の種類の番号
        public int PositionNumber;  //敵の出現位置の配列番号
	}
    //敵データ格納配列
    public List<EnemyData> eds = new List<EnemyData>();
    //敵の種類
    [SerializeField] GameObject[] EnemyPrefabs = new GameObject[] { };
    //敵の出現位置
    Vector3[] SpawnPositions;

    //フレームカウント用
    int NowFlame;

    //前フレームのウェーブ数
    int PreWave;
    /// <summary>
    /// SEクラス
    /// 柄子
    /// </summary>
    [SerializeField] AudioSE seClass = null;
    // Start is called before the first frame update
    void Start()
    { 
        //変数初期化
        NowFlame = 0;
        PreWave = 0;

        //出現位置設定（現在テスト用のみ格納）
        SpawnPositions = new Vector3[] {
            new Vector3(-53,13,-9),     //0
            new Vector3(-45,13,-25),    //1
            new Vector3(-34,13,-39),    //2
            new Vector3(-19,13,-50),    //3
            new Vector3(0,13,-54),      //4
            new Vector3(19,13,-50),     //5
            new Vector3(34,13,-39),     //6
            new Vector3(45,13,-25),     //7
            new Vector3(53,13,-9),      //8
            new Vector3(53,13,9),       //9
            new Vector3(45,13,25),      //10
            new Vector3(34,13,39),      //11
            new Vector3(19,13,50),      //12
            new Vector3(0,13,54),       //13
            new Vector3(-19,13,50),     //14
            new Vector3(-34,13,39),     //15
            new Vector3(-45,13,25),     //16
            new Vector3(-53,13,9),      //17
        };

        //最初のウェーブ読み込み（仮置き）
        ReadEnemyFile read = GetComponent<ReadEnemyFile>();
        eds = read.ReadFile_EnemyData("Wave" + GameManager.waveNowCnt + ".txt");
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        //ゲーム中のみ処理
        if (GameManager.mode != GameMode.InGame) { return; }

        //ウェーブチェンジ時にテキストファイルを読み込む
        if (Check_ChengeWave())
        {
            eds.Clear();
            ReadEnemyFile read = GetComponent<ReadEnemyFile>();
            eds = read.ReadFile_EnemyData("Wave" + GameManager.waveNowCnt + ".txt");
            NowFlame = 0;
            PreWave = GameManager.waveNowCnt;
        }
        //フレーム数に応じて敵を出現させる
        for (int i = 0; i < eds.Count; i++)
        {
            if (eds[i].SpawnRate == NowFlame)
            {
                GameObject Enemy;
                Enemy = Instantiate(EnemyPrefabs[eds[i].EnemyType]);
                Enemy.transform.position = SpawnPositions[eds[i].PositionNumber];
                //(Clone)←消す
                Enemy.name = EnemyPrefabs[eds[i].EnemyType].name;
                //SE
                this.seClass.AudioSESet(8, 0.3f);
            }
        }
        NowFlame++;
    }
    //ウェーブの変更をチェック
    bool Check_ChengeWave()
	{
        //現在のフレームが前のフレームと違ったらtrue
        if(PreWave!= GameManager.waveNowCnt)
        {
            return true;
        }
        return false;
	}
}
