﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 画像変更
/// </summary>
public class ImageChangeController : MonoBehaviour
{
	/// <summary>
	/// 変更するImage
	/// </summary>
	[SerializeField] Image imageSprite = null;
	/// <summary>
	/// 表示する画像
	/// </summary>
	[SerializeField] Sprite[] sprites = null;
	/// <summary>
	/// 次へのボタン
	/// </summary>
	[SerializeField] Button nextButton = null;
	/// <summary>
	/// 前へのボタン
	/// </summary>
	[SerializeField] Button prevButton = null;
	/// <summary>
	/// 画像番号
	/// </summary>
	int nowCnt;
	//-------------------------------------------------
	void Start()
	{
		//初期設定
		this.nowCnt = 0;
		SetImage();

		CheckButton();
	}
	//-------------------------------------------------
	/// <summary>
	/// 画像変更
	/// </summary>
	void SetImage()
	{
		this.imageSprite.sprite = this.sprites[this.nowCnt];
	}
	//-------------------------------------------------
	/// <summary>
	/// 画像切り替え(次へ)
	/// </summary>
	public void ImageChangeNext()
	{
		if(this.sprites.Length - 1 > nowCnt)
		{
			this.nowCnt++;
			SetImage();

			CheckButton();
		}
	}
	//-------------------------------------------------
	/// <summary>
	/// 画像切り替え(前へ)
	/// </summary>
	public void ImageChangePrev()
	{
		if (nowCnt > 0)
		{
			this.nowCnt--;
			SetImage();

			CheckButton();
		}
	}
	//-------------------------------------------------
	/// <summary>
	/// ボタンの無効・有効化
	/// </summary>
	void CheckButton()
	{
		//最後の画像だった場合、ボタン無効化
		if (this.sprites.Length - 1 == nowCnt)	{ this.nextButton.interactable = false; }
		else									{ this.nextButton.interactable = true; }

		//最初の画像だった場合、ボタン無効化
		if (0 == nowCnt)	{ this.prevButton.interactable = false; }
		else				{ this.prevButton.interactable = true; }
	}
	//-------------------------------------------------
}
