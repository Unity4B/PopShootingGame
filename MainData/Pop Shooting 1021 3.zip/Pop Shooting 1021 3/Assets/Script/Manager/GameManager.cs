﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------
/// <summary>
/// ゲームモード
/// </summary>
public enum GameMode
{
    InGame, //ゲーム中
    End,    //ゲーム終了
    Menu,   //メニュー
}
//-------------------------------------------------
/// <summary>
/// ゲームシーン統括
/// </summary>
public class GameManager : MonoBehaviour
{
    //フィールド
    /// <summary>
    /// ゲームモード
    /// </summary>
    public static GameMode mode;
    /// <summary>
    /// 現在のウェーブ数
    /// </summary>
    public static int waveNowCnt;
    /// <summary>
    /// ゲームスコア
    /// </summary>
    public static int score;
    /// <summary>
    /// ウェーブ上限
    /// </summary>
    public static int limitWaveCnt = 5;
    /// <summary>
    /// ウェーブ切り替えのフレーム数
    /// </summary>
    [SerializeField] int limitFrameCnt = 3000;
    /// <summary>
    /// 経過フレーム数
    /// </summary>
    int frameCnt;
    /// <summary>
    /// BGMクラス
    /// </summary>
    [SerializeField] AudioBGM bgmClass = null;
    /// <summary>
    /// SEクラス
    /// </summary>
    [SerializeField] AudioSE seClass = null;
    /// <summary>
    /// エネミー管理
    /// </summary>
    [SerializeField] EnemyManager enemyManager = null;
    /// <summary>
    /// 結果表示オブジェクト
    /// </summary>
    [SerializeField] GameObject resultObj = null;
    //-------------------------------------------------
    void Awake()
    {
        mode = GameMode.InGame;

        //ウェーブ初期化
        waveNowCnt = 1;

        score = 0;

        this.frameCnt = 0;
    }

    void Start()
    {
        //BGM
        this.bgmClass.AudioBGMSet(1, 0.2f);
    }

    void FixedUpdate()
    {
        switch (mode)
        {
            //ゲーム中の処理
            case GameMode.InGame: WaveCount();  break;
            //ゲーム終了の処理
            case GameMode.End: break;
        } 
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }

        if (CheckGameClear()) { GameClear(); }
    }
    //-------------------------------------------------
    /// <summary>
    /// ウェーブカウント
    /// </summary>
    void WaveCount()
	{
        if(this.frameCnt > this.limitFrameCnt && waveNowCnt < limitWaveCnt) 
        {
            //ウェーブ数が上限に達した場合
            if (waveNowCnt + 1 > limitWaveCnt) { return; }


            //ウェーブチェンジ
            //SE
            this.seClass.AudioSESet(7, 0.3f);


            waveNowCnt++;
            //カウントリセット
            this.frameCnt = 0;
        }
        else
		{
            //カウント
            this.frameCnt++;
		}
	}
    //-------------------------------------------------
    /// <summary>
    /// ゲーム終了処理
    /// </summary>
    void GameEnd()
	{
        this.resultObj.SetActive(true);
        mode = GameMode.End;
	}
    //-------------------------------------------------
    /// <summary>
    /// ゲームのクリア条件を満たしているか
    /// </summary>
    /// <returns>結果</returns>
    bool CheckGameClear()
	{
        //ウェーブ数が上限に達していない場合
        if (waveNowCnt < limitWaveCnt || this.frameCnt < this.limitFrameCnt) { return false; }
        //エネミーが存在する場合
        if (this.enemyManager.enemys.Count > 0) { return false; }
        return true;
	}
    //-------------------------------------------------
    /// <summary>
    /// ゲームクリア処理
    /// </summary>
    public void GameClear()
	{
        waveNowCnt = limitWaveCnt;
        //SE
        this.seClass.AudioSESet(5, 0.4f);
        GameEnd();
	}
    //-------------------------------------------------
    /// <summary>
    /// ゲームオーバー処理
    /// </summary>
    public void GameOver()
	{
        //SE
        this.seClass.AudioSESet(6, 0.4f);
        GameEnd();
	}
}
