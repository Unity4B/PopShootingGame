﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class OptionManager : MonoBehaviour
{
    public GameObject weaponSelectCanvas;
    public GameObject start, exit, weapon1, weapon2, clickButton;   //clickButton以外はinspectorにアタッチさせる
    /// <summary>
    /// 選んだボタン番号　
    /// 柄子
    /// </summary>
    public int buttonNum;
    /// <summary>
    /// SEクラス
    /// </summary>
    AudioSE seClass = null;


    // Start is called before the first frame update
    void Start()
    {
        weapon1.GetComponentInChildren<Text>().text = WeaponGenerator.weaponDatas[0].WName;
        weapon2.GetComponentInChildren<Text>().text = WeaponGenerator.weaponDatas[1].WName;
        weaponSelectCanvas.SetActive(false);

        this.seClass = GameObject.FindObjectOfType<AudioSE>();
    }

    public void OnbuttonDown_Start()
	{
        for (int i = 0; i < WeaponGenerator.weaponDatas.Length; i++)
        {
            //武器情報がセットされていなければ、シーン変移せず
            if (WeaponGenerator.weaponDatas[i].WType == WeaponType.None) { return; }
        }
        //SE
        this.seClass.AudioSESet(1, 0.5f);

        SceneChangeController sceneClass = GameObject.FindObjectOfType<SceneChangeController>();

        sceneClass.SceneChange("MainGameScene");
    }
    public void OnbuttonDown_Exit()
    {
        //テキストなどを変えました　柄子
        //SE
        this.seClass.AudioSESet(1, 0.5f);

        weapon1.GetComponentInChildren<Text>().text = WeaponGenerator.weaponDatas[0].WName;
        weapon2.GetComponentInChildren<Text>().text = WeaponGenerator.weaponDatas[1].WName;
        Destroy(transform.parent.gameObject);
    }
    public void OnbuttonDown_Weapon1()
    {
        clickButton = weapon1;
        this.buttonNum = 0;
        weaponSelectCanvas.SetActive(true);
        gameObject.SetActive(false);
        //SE
        this.seClass.AudioSESet(1, 0.5f);
    }
    public void OnbuttonDown_Weapon2()
    {
        clickButton = weapon2;
        this.buttonNum = 1;
        weaponSelectCanvas.SetActive(true);
        gameObject.SetActive(false);
        //SE
        this.seClass.AudioSESet(1, 0.5f);
    }
}
