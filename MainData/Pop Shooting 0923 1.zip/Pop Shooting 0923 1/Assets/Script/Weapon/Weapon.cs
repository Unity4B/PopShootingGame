﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 武器種
/// </summary>
public enum WeaponType
{
    None        = -1,   //無
    HundGun     = 0,    //ハンドガン
    AssaultGun  = 1,    //アサルトライフル
    ShotGun     = 2     //ショットガン
}
//-------------------------------------------------
/// <summary>
/// 武器
/// </summary>
public abstract class Weapon : MonoBehaviour
{
    //-------------------------------------------------
    //フィールド
    /// <summary>
    /// 武器データ
    /// </summary>
    public WeaponData wData;
    /// <summary>
    /// SEクラス
    /// </summary>
    public AudioSE seClass;
    //-------------------------------------------------
    public virtual void Awake()
	{
        this.seClass = GameObject.FindObjectOfType<AudioSE>();
	}
    //-------------------------------------------------
    /// <summary>
    /// 弾生成
    /// </summary>
    public void BulletGenerate()
	{
        GameObject bullet_          = Instantiate<GameObject>(this.wData.bullet);
        bullet_.transform.position  = transform.position;
        bullet_.transform.rotation  = transform.rotation;

	}
    //-------------------------------------------------
    /// <summary>
    /// 射撃処理
    /// </summary>
    public abstract void Shot();
    //-------------------------------------------------
}
