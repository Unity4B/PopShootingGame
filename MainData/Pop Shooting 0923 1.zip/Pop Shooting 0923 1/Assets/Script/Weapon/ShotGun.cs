﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// ショットガン
/// </summary>
public class ShotGun : Weapon
{
    //フィールド
    /// <summary>
    /// 射撃可能か
    /// </summary>
    bool isShotPossible;
    /// <summary>
    /// 初期角度
    /// </summary>
    Vector3 sRotation;
    //-------------------------------------------------
    public override void Awake()
    {
        base.Awake();
        this.wData.SetWeaponType(WeaponType.ShotGun);
        this.isShotPossible = true;

        //サイズ調整
        transform.localScale = new Vector3(0.03f, 0.03f, 0.03f);
        transform.Rotate(new Vector3(270.0f, 0.0f, 0.0f));

        this.sRotation = transform.rotation.eulerAngles;
    }

	void Update()
	{
        //射撃間隔を確認
        if (this.wData.deltaTime >= this.wData.interval || this.isShotPossible)
        {
            //射撃可能に
            this.isShotPossible = true;
            this.wData.deltaTime = 0.0f;
        }
        else
        {
            //時間計測
            this.wData.deltaTime += Time.deltaTime;
        }

    }
    //-------------------------------------------------
    public override void Shot()
    {
        //射撃可能でなければ処理せず
		if (!this.isShotPossible) { return; }

        //マウス入力状態に応じて
        if (ScreenTouch.touchState == TouchPhase.Began)
        {
            Vector2 preAngle = new Vector2(0.0f,0.0f);

            for (int i = 0; i < 4; i++)
            {
                //発射角をランダムに
                Vector2 sAngle  = new Vector2(Random.Range(-7.0f,7.0f),Random.Range(-7.0f,7.0f));
                sAngle -= preAngle;

                //回転
                transform.Rotate(sAngle.x, sAngle.y, 0.0f);
                //弾生成
                BulletGenerate();
                //SE
                this.seClass.AudioSESet(4, 0.1f);

                preAngle = sAngle;
            }
            //元に戻す
            Vector3 angle = transform.root.rotation.eulerAngles - (transform.rotation.eulerAngles - this.sRotation);
            transform.Rotate(angle);

            this.isShotPossible = false;
        }

    }
    //-------------------------------------------------
}
