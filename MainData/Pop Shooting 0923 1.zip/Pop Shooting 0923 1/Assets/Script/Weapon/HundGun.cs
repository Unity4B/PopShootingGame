﻿using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------
/// <summary>
/// ハンドガン
/// </summary>
public class HundGun : Weapon
{
	//-------------------------------------------------
	public override void Awake()
	{
		base.Awake();
		this.wData.SetWeaponType(WeaponType.HundGun);

		//サイズ調整
		transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
		transform.Rotate(new Vector3(270.0f, 0.0f, 270.0f));
	}

	//-------------------------------------------------
	//射撃処理
	public override void Shot()
	{
		//マウス入力状態に応じて
		if (ScreenTouch.touchState == TouchPhase.Began)
		{
			BulletGenerate();
			//SE
			this.seClass.AudioSESet(4, 0.4f);
		}

	}
	//-------------------------------------------------
}
