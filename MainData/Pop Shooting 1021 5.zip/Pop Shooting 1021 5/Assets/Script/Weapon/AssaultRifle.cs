﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------
/// <summary>
/// アサルトライフル
/// </summary>
public class AssaultRifle : Weapon
{

    //-------------------------------------------------
    public override void Awake()
    {
        base.Awake();
        this.wData.SetWeaponType(WeaponType.AssaultGun);

        //サイズ調整
        transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
        transform.Rotate(new Vector3(290.0f,11.0f,270.0f));
    }

    //-------------------------------------------------
    public override void Shot()
    {
        //マウス入力状態に応じて
        if (ScreenTouch.touchState == TouchPhase.Moved)
        {
            if (this.wData.deltaTime >= this.wData.interval)
            {
                BulletGenerate();
                //SE
                this.seClass.AudioSESet(4, 0.4f);

                this.wData.deltaTime = 0.0f;
            }
            else
            {
                this.wData.deltaTime += Time.deltaTime;
            }
        }
        else if (ScreenTouch.touchState == TouchPhase.Began)
        {
            this.wData.deltaTime = 0.0f;

            BulletGenerate();
            //SE
            this.seClass.AudioSESet(4, 0.4f);
        }
        else if (ScreenTouch.touchState == TouchPhase.Ended)
        {
            this.wData.deltaTime = 0.0f;
        }
    }
    //-------------------------------------------------
}
