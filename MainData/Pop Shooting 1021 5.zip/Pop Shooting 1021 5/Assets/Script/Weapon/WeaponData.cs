﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------
/// <summary>
/// 武器データクラス
/// </summary>
[System.Serializable]
public class WeaponData
{
    //フィールド
    /// <summary>
    /// 武器の種類
    /// </summary>
    WeaponType          wType;
    /// <summary>
    /// 武器名
    /// </summary>
    string              wName;
    /// <summary>
    /// 弾の種類
    /// </summary>
    public GameObject   bullet;
    /// <summary>
    /// 射撃間隔
    /// </summary>
    public float        interval;
    /// <summary>
    /// 射撃間隔カウンタ
    /// </summary>
    public float        deltaTime;
    //-------------------------------------------------
    //プロパティ
    /// <summary>
    /// 武器の種類
    /// </summary>
    public WeaponType WType
    {
        get { return this.wType; }
        private set { this.wType = value; }
    }
    /// <summary>
    /// 武器名
    /// </summary>
    public string WName
    {
        get { return this.wName; }
        private set { this.wName = value; }
    }
    //-------------------------------------------------
    public WeaponData()
    {
        SetWeaponType(WeaponType.None);
    }
    //-------------------------------------------------
    /// <summary>
    /// 武器の種類を設定
    /// </summary>
    /// <param name="type"></param>
    public void SetWeaponType(WeaponType type)
    {
        //更新
        this.WType = type;

        //武器種ごとに名前設定
        switch (type)
        {
            case WeaponType.None:       this.WName = "未設定";     break;
            case WeaponType.HundGun:    this.WName = "ハンドガン"; break;
            case WeaponType.AssaultGun: this.WName = "アサルトガン"; break;
            case WeaponType.ShotGun:    this.WName = "ショットガン"; break;
            default: Debug.LogWarning("武器種が設定されていません。"); break;
        }
    }

}
