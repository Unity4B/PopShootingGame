﻿using System.Collections;
using System.Collections.Generic;
using System;
using System.IO;
using System.Text;
using UnityEngine;
using System.Numerics;
using Edata = EnemyGenerater.EnemyData;

public class ReadEnemyFile : MonoBehaviour
{
    string FilePath;
    EnemyGenerater eg;
    Edata ed;
    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    //敵Waveデータファイル読み込み関数
    public List<Edata> ReadFile_EnemyData(string FileName)
	{
        FilePath = Application.dataPath + "/" + FileName;
        FileInfo fi = new FileInfo(FilePath);
        StreamReader sr = new StreamReader(fi.OpenRead(), Encoding.UTF8);
        List<Edata> datas = new List<Edata>();
        while (sr.Peek() != -1)
        {
            string data = sr.ReadLine();
            Edata d = new Edata();
            d.SpawnRate = int.Parse(data.Split('.')[0]);
            d.EnemyType = int.Parse(data.Split('.')[1]);
            d.PositionNumber = int.Parse(data.Split('.')[2]);
            datas.Add(d);
        }
        datas.Sort((a, b) => a.SpawnRate - b.SpawnRate);
        return datas;
	}
}
