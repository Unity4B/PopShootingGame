﻿using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using UnityEngine;

public enum BulletType
{
    Normal,     //通常弾
    Pierce,     //貫通弾
    Explosive,  //爆発弾
}

public class Bullet : MonoBehaviour
{
    private BulletType bulletType;  //種類
    public int bPower; //威力
    
    public Bullet(BulletType bulletType_)
    {
        this.bulletType = bulletType_;

        switch(this.bulletType)
        {
            case BulletType.Normal:
                {
                    this.bPower = 1;
                    break;
                }
            case BulletType.Pierce:
                {
                    this.bPower = 1;
                    break;
                }
            case BulletType.Explosive:
                {
                    this.bPower = 1;
                    break;
                }
        }
    }

	public void Shoot(UnityEngine.Vector3 dir)
	{
       this.GetComponent<Rigidbody>().AddForce(dir);
    }
}
