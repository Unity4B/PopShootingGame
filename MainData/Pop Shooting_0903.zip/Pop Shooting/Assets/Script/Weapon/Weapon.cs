﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Weapon : MonoBehaviour
{
    //武器データ
    [System.Serializable]
    public struct WeaponData
	{
        public GameObject   bullet;     //弾の種類
        public float        interval;   //射撃間隔
        public float        deltaTime;  //射撃間隔カウンタ

	}
    public WeaponData wData;

    public void BulletGenerate()
	{
        GameObject bullet_          = Instantiate<GameObject>(this.wData.bullet);
        bullet_.transform.position  = transform.position;
	}

    //射撃処理
    public abstract void Shot();
}
