﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------
/// <summary>
/// UI:スコア表示テキスト
/// </summary>
public class ScoreTextController : MonoBehaviour
{
    //フィールド
    /// <summary>
    /// スコア表示テキスト
    /// </summary>
    [SerializeField] Text scoreText = null;
    /// <summary>
    /// 前のスコア
    /// </summary>
    int preScore;
    //-------------------------------------------------
    void Start()
    {
        InfoUpdate();
    }

    void Update()
    {
        //変更されていればUIに反映
        if (CheckScoreChange())
		{
            InfoUpdate();
		}
    }
    //-------------------------------------------------
    /// <summary>
    /// 前フレームと比較してスコアが変わっているかチェック
    /// </summary>
    /// <returns></returns>
    bool CheckScoreChange()
	{
        return GameManager.score != this.preScore;
	}
    //-------------------------------------------------
    /// <summary>
    /// 情報更新
    /// </summary>
    void InfoUpdate()
	{
        //更新
        this.scoreText.text = "SCORE:" + GameManager.score.ToString("D4");

        this.preScore = GameManager.score;
	}
}
