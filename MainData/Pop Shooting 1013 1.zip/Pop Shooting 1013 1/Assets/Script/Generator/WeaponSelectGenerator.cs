﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------
/// <summary>
/// 武器選択画面生成
/// </summary>
public class WeaponSelectGenerator : MonoBehaviour
{
	//フィールド
	/// <summary>
	/// 生成する選択画面
	/// </summary>
	[SerializeField] GameObject weaponSelectObj = null;
	/// <summary>
	/// 生成されたオブジェクト
	/// </summary>
	GameObject obj;
	/// <summary>
	/// SEクラス
	/// </summary>
	[SerializeField] AudioSE seClass = null;
	//-------------------------------------------------
	/// <summary>
	/// 武器選択画面生成コマンド
	/// </summary>
	public void WeaponSelectGenerate()
	{
		//既に存在する場合、処理しない
		if(this.obj != null) { return; }

		//SE
		this.seClass.AudioSESet(1, 0.5f);

		this.obj = Instantiate<GameObject>(this.weaponSelectObj);

	}
	//-------------------------------------------------

}
