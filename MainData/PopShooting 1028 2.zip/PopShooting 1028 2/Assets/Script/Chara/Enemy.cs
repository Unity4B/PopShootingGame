﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : Chara
{
	public GameObject enemyObject;
	private GameObject targetObject;    //ターゲット

	private int Enemylife;
	private float Enemyspeed;     //敵速度
	private int Attack_damege;    //攻撃力
	private float HitPower;     //ヒット時の力

	private Vector3 targetPos;     //LookAt調整用
	private bool AttackSwitch;        //アタック呼び出し

	private float attackCount;      //的の攻撃間隔カウント
	Rigidbody rigidBody;
	private ParticleGenerator pg;

	/// <summary>
	/// SEクラス
	/// 柄子
	/// </summary>
	AudioSE seClass;

	public enum EnemyType     //エネミー種類 
	{
		Normal = 0,              //通常型
		Powerful = 1,            //高威力型
		Quick = 2                //高速型
	};
	public EnemyType enemyType;

	public Enemy()
	{
	}

	void Start()
	{
		targetObject = GameObject.FindGameObjectWithTag("Player");//プレイヤ検索

		rigidBody = GetComponent<Rigidbody>();
		pg = GameObject.Find("Generator").GetComponent<ParticleGenerator>();

		this.seClass = GameObject.FindObjectOfType<AudioSE>();

		this.charaParam = new Param(0.0f, Enemylife, 0, Enemyspeed, Param.Status.Move);

		attackCount = 0f;
		//-----------------------------------------------------------------------------
		//エネミータイプ変更
		switch (this.enemyType)
		{
			case EnemyType.Normal:
				Debug.Log("通常型");

				Enemylife = enemyObject.GetComponent<Enemy_Normal>().enemyHP();
				Enemyspeed = enemyObject.GetComponent<Enemy_Normal>().moveSpeed();
				Attack_damege = enemyObject.GetComponent<Enemy_Normal>().damege();
				HitPower = enemyObject.GetComponent<Enemy_Normal>().knockback();

				break;

			case EnemyType.Powerful:
				Debug.Log("高威力型");

				Enemylife = enemyObject.GetComponent<Enemy_Powerful>().enemyHP();
				Enemyspeed = enemyObject.GetComponent<Enemy_Powerful>().moveSpeed();
				Attack_damege = enemyObject.GetComponent<Enemy_Powerful>().damege();
				HitPower = enemyObject.GetComponent<Enemy_Powerful>().knockback();

				break;

			case EnemyType.Quick:
				Debug.Log("高速型");

				Enemylife = enemyObject.GetComponent<Enemy_Quick>().enemyHP();
				Enemyspeed = enemyObject.GetComponent<Enemy_Quick>().moveSpeed();
				Attack_damege = enemyObject.GetComponent<Enemy_Quick>().damege();
				HitPower = enemyObject.GetComponent<Enemy_Quick>().knockback();

				break;
		}

	}

	void Update()
	{
		Anim();
		//ゲーム中のみ処理
		if (GameManager.mode != GameMode.InGame) { return; }

		EnemyLook();

		Move();


		Debug.Log("スピード" + Enemyspeed);

		//柄子
		DebugText.Log(name + ":" + this.charaParam.status.ToString() + ":" + this.Attack_damege.ToString());
	}

	public override void Attack()
	{
		//攻撃アニメーション
		this.anim.SetTrigger("Attack");

	}
	public override void Hit(int damage_)
	{
		//消滅モードの場合、処理せず
		if (this.charaParam.status == Param.Status.Dead) { return; }

		//当たり判定の後の処理
		Enemylife -= damage_;

		//体力が残っているか判定
		if (Enemylife <= 0)
		{
			this.charaParam.status = Param.Status.Dead;
			this.anim.SetTrigger("EnemyDead");
		}
		else
		{
			this.anim.SetTrigger("HitCheck");
			this.seClass.AudioSESet(3, 0.2f);
		}
		Debug.Log("ライフ" + Enemylife);

	}
	public override void WaitingUpdate()
	{

		//待機中の処理
	}
	public override void AttackUpdate()
	{
		//攻撃中の処理
		attackCount += Time.deltaTime;
		if (attackCount >= 1.5f)
		{
			Attack();
			Debug.Log("敵の攻撃呼び出し");
			attackCount = 0f;
		}
	}

	public void AttackAnimationEvent()
	{
		targetObject.GetComponent<Player>().Hit(Attack_damege);
		Debug.Log("敵の攻撃仮");
	}
	public override void MoveUpdate()
	{
		//動いている間の処理
		transform.position = Vector3.MoveTowards(transform.position, targetPos, Enemyspeed * Time.deltaTime);

		this.anim.SetInteger("EnemyType", (int)this.enemyType);
	}
	public override void HitUpdate()
	{
		//被弾中の処理
	}

	public override void WaitingAnim()
	{
		//待機中のアニメーション
	}
	public override void AttackAnim()
	{
		//攻撃中のアニメーション
	}
	public override void MoveAnim()
	{
		//動いている間のアニメーション
	}
	public override void HitAnim()
	{
		//被弾中のアニメーション

	}
	void EnemyLook()
	{
		//向き調整
		targetPos = targetObject.transform.position;
		targetPos.y = transform.position.y;
		transform.LookAt(targetPos);
	}

	//死亡時の判定
	void Destroy()
	{
		pg.Smoke(transform.position);
		Destroy(gameObject);
		//SE
		this.seClass.AudioSESet(9, 0.3f);

		//スコア加算
		GameManager.score += 100 * GameManager.waveNowCnt;
	}

	void OnTriggerEnter(Collider col)
	{
		if (col.gameObject.tag == "Player")//ヒット当たり判定　
		{
			Attack();
			this.charaParam.status = Param.Status.Attack;
		}
	}
}