﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Powerful : MonoBehaviour
{
    public int HP = 20;
    public float movespeed = 0.25f;
    public int Power = 4;
    public float HitPower = 0.5f;

    public int enemyHP()
    {
        return HP;
    }
    public float moveSpeed()
    {
        return movespeed;
    }
    public int damege()
    {
        return Power;
    }
    public float knockback()
    {
        return HitPower;
    }
}
