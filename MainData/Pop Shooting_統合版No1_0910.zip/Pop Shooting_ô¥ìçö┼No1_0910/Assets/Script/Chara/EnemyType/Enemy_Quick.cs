﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Quick : MonoBehaviour
{
    public int HP = 10;
    public float movespeed = 1.0f;
    public int Power = 2;
    public float HitPower = 1.5f;

    public int enemyHP()
    {
        return HP;
    }
    public float moveSpeed()
    {
        return movespeed;
    }
    public int damege()
    {
        return Power;
    }
    public float knockback()
    {
        return HitPower;
    }
}
