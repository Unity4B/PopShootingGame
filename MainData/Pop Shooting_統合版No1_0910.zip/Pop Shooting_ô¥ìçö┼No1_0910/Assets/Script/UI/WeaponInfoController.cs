﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//UI:装備中の武器情報表示
public class WeaponInfoController : MonoBehaviour
{
    Image               wImage;     //表示画像
    Text                wText;      //表示テキスト
    Player              player;     //表示するターゲット
    Weapon.WeaponType   prewType;   //前フレームの武器種

    void Start()
    {
        this.wImage     = GetComponent<Image>();
        this.wText      = transform.GetChild(0).GetComponent<Text>();
        this.player     = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
        this.prewType   = Weapon.WeaponType.None;
    }

    void Update()
    {
        //変更されていればUIに反映
        if(Check_ChangeWeapon())
		{



            //更新
            this.prewType = this.player.weapon.GetComponent<Weapon>().wData.wType;
		}

    }

    //前フレームと比較して武器が変更されているか確認
    bool Check_ChangeWeapon()
	{
        return this.player.weapon.GetComponent<Weapon>().wData.wType == this.prewType;
	}
}
