﻿using System.Collections;
using System.Collections.Generic;
using System;
using System.IO;
using System.Text;
using UnityEngine;
using System.Numerics;
using Edata = EnemyGenerater.EnemyData;

public class ReadEnemyFile : MonoBehaviour
{
    string FilePath;
    EnemyGenerater eg;
    Edata ed;
    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    //敵Waveデータファイル読み込み関数
    public List<Edata> ReadFile_EnemyData(string FileName)
	{
        //ファイルパス取得
        FilePath = Application.dataPath + "/" + FileName;

        //ファイル読み込み
        /****************************************************
         出現までのフレーム数,敵のタイプ番号,出現位置配列番号
            ↑の書き方で１行に１体分ずつ記述してください 
        ****************************************************/
        try
        {
            FileInfo fi = new FileInfo(FilePath);
            StreamReader sr = new StreamReader(fi.OpenRead(), Encoding.UTF8);

            //ファイルから取得したデータの書き込み
            List<Edata> datas = new List<Edata>();
            while (sr.Peek() != -1)
            {
                string data = sr.ReadLine();
                Edata d = new Edata();
                d.SpawnRate = int.Parse(data.Split(',')[0]);       //出現までのフレーム数を取得
                d.EnemyType = int.Parse(data.Split(',')[1]);       //出現する敵のタイプ番号を取得 
                d.PositionNumber = int.Parse(data.Split(',')[2]);  //出現位置の配列番号を取得
                datas.Add(d);
            }
            return datas;
        }
        //ファイル読み込み失敗
        catch
        {
            Debug.Log("ファイルの読み込みに失敗しました");

            //データなしのEnemyData配列を返す
            List<Edata> NoData = new List<Edata>();
            return NoData;
        }
	}
}
