﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------
/// <summary>
/// 武器
/// </summary>
public abstract class Weapon : MonoBehaviour
{
    /// <summary>
    /// 武器種
    /// </summary>
    public enum WeaponType
	{
        None        = -1,   //無
        HundGun     = 0,    //ハンドガン
        AssaultGun  = 1,    //アサルトライフル
        
	}
    //-------------------------------------------------
    /// <summary>
    /// 武器データ構造体
    /// </summary>
    [System.Serializable]
    public struct WeaponData
	{
        public WeaponType   wType;      //武器の種類
        public GameObject   bullet;     //弾の種類
        public float        interval;   //射撃間隔
        public float        deltaTime;  //射撃間隔カウンタ

	}
    //-------------------------------------------------
    /// <summary>
    /// 弾生成
    /// </summary>
    public void BulletGenerate()
	{
        GameObject bullet_          = Instantiate<GameObject>(this.wData.bullet);
        bullet_.transform.position  = transform.position;
        bullet_.transform.rotation  = transform.rotation;
	}
    //-------------------------------------------------
    /// <summary>
    /// 武器データ
    /// </summary>
    public WeaponData wData;
    //-------------------------------------------------
    /// <summary>
    /// 射撃処理
    /// </summary>
    public abstract void Shot();
    //-------------------------------------------------
}
