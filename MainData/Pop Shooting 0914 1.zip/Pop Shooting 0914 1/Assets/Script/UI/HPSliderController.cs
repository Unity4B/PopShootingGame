﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// UI:プレイヤーHPスライダー
/// </summary>
public class HPSliderController : MonoBehaviour
{
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
