﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// UI:Wave表示テキスト
/// </summary>
public class WaveTextController : MonoBehaviour
{
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
