﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------
/// <summary>
/// UI:装備中の武器情報表示
/// </summary>
public class WeaponInfoController : MonoBehaviour
{
    //フィールド
    /// <summary>
    /// 表示画像
    /// </summary>
    [SerializeField] Image  wImage = null;
    /// <summary>
    /// 表示テキスト
    /// </summary>
    [SerializeField] Text   wText = null;
    /// <summary>
    /// プレイヤークラス
    /// </summary>
    [SerializeField] Player player = null;
    /// <summary>
    /// 前フレームの武器種
    /// </summary>
    Weapon.WeaponType       prewType;
    //-------------------------------------------------
    void Start()
    {
        this.prewType   = Weapon.WeaponType.None;
    }

    void Update()
    {
        //変更されていればUIに反映
        if(Check_ChangeWeapon())
		{



            //更新
            this.prewType = this.player.weapon.wData.wType;
		}

    }
    //-------------------------------------------------
    /// <summary>
    /// 前フレームと比較して武器が変更されているか確認
    /// </summary>
    /// <returns></returns>
    bool Check_ChangeWeapon()
	{
        return this.player.weapon.wData.wType != this.prewType;
	}
}
