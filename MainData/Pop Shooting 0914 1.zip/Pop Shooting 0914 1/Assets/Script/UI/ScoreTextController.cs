﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------
/// <summary>
/// UI:スコア表示テキスト
/// </summary>
public class ScoreTextController : MonoBehaviour
{
    //-------------------------------------------------
    void Start()
    {
        
    }

    void Update()
    {
        
    }
    //-------------------------------------------------
}
