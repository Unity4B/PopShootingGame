﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

//-------------------------------------------------
/// <summary>
/// UI:リザルト
/// </summary>
public class ResultManager : MonoBehaviour
{
    //フィールド
    /// <summary>
    /// ウェーブ数表示テキスト
    /// </summary>
    [SerializeField] Text waveText = null;
    /// <summary>
    /// スコア表示テキスト
    /// </summary>
    [SerializeField] Text scoreText = null;
    //-------------------------------------------------
    void Start()
    {
        DisplayText();
    }

    void Update()
    {
        //Time.timeScale = 0; //ゲーム進行を止める
    }
    //-------------------------------------------------
    /// <summary>
    /// リトライボタンクリック時の処理
    /// </summary>
    public void OnbuttonDown_Retry()
    {
        SceneManager.LoadScene(""); //メインゲーム画面呼び出し
    }

    /// <summary>
    /// 終了ボタンクリック時の処理
    /// </summary>
    public void OnbuttonDown_Exit()
    {
        #if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
        #elif UNITY_STANDALONE
             UnityEngine.Application.Quit();
        #endif
    }
    //-------------------------------------------------
    /// <summary>
    /// 結果表示
    /// </summary>
    void DisplayText()
    {
        this.scoreText.text = "SCORE:" + GameManager.score.ToString("D4");
        this.waveText.text = "WAVE:" + GameManager.waveNowCnt;
    }
}
