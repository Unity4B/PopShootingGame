﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------
/// <summary>
/// 武器
/// </summary>
public abstract class Weapon : MonoBehaviour
{
    /// <summary>
    /// 武器種
    /// </summary>
    public enum WeaponType
	{
        None        = -1,   //無
        HundGun     = 0,    //ハンドガン
        AssaultGun  = 1,    //アサルトライフル
        
	}
    //-------------------------------------------------
    /// <summary>
    /// 武器データ構造体
    /// </summary>
    [System.Serializable]
    public struct WeaponData
	{
        //フィールド
        /// <summary>
        /// 武器の種類
        /// </summary>
        WeaponType          wType;
        /// <summary>
        /// 武器名
        /// </summary>
        string              wName;
        /// <summary>
        /// 弾の種類
        /// </summary>
        public GameObject   bullet;
        /// <summary>
        /// 射撃間隔
        /// </summary>
        public float        interval;
        /// <summary>
        /// 射撃間隔カウンタ
        /// </summary>
        public float        deltaTime;
        //-------------------------------------------------
        //プロパティ
        /// <summary>
        /// 武器の種類
        /// </summary>
        public WeaponType WType
		{
			get         { return this.wType; }
            private set { this.wType = value; }
		}
        /// <summary>
        /// 武器名
        /// </summary>
        public string WName
        {
            get         { return this.wName; }
            private set { this.wName = value; }
        }
        //-------------------------------------------------
        /// <summary>
        /// 武器の種類を設定
        /// </summary>
        /// <param name="type"></param>
        public void SetWeaponType(WeaponType type)
		{
            //更新
            this.WType = type;

            //武器種ごとに名前設定
            switch(type)
			{
                case WeaponType.HundGun:    this.WName = "ハンドガン";   break;
                case WeaponType.AssaultGun: this.WName = "アサルトガン"; break;
                default:    Debug.LogWarning("武器種が設定されていません。");break;
			}
		}

	}
    //-------------------------------------------------
    /// <summary>
    /// 武器データ
    /// </summary>
    public WeaponData wData;
    //-------------------------------------------------
    /// <summary>
    /// 弾生成
    /// </summary>
    public void BulletGenerate()
	{
        GameObject bullet_          = Instantiate<GameObject>(this.wData.bullet);
        bullet_.transform.position  = transform.position;
        bullet_.transform.rotation  = transform.rotation;
	}
    //-------------------------------------------------
    /// <summary>
    /// 射撃処理
    /// </summary>
    public abstract void Shot();
    //-------------------------------------------------
}
