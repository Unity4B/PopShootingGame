﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor.UIElements;
using UnityEngine;

//-------------------------------------------------
/// <summary>
/// アサルトライフル
/// </summary>
public class AssaultRifle : Weapon
{

    //-------------------------------------------------
    void Start()
    {
        this.wData.SetWeaponType(WeaponType.AssaultGun);
    }

    void Update()
    {

    }
    //-------------------------------------------------
    public override void Shot()
    {
        //マウス入力状態に応じて
        if (ScreenTouch.touchState == TouchPhase.Began)
        {
            BulletGenerate();
        }
        else if (ScreenTouch.touchState == TouchPhase.Moved)
        {
            if (this.wData.deltaTime >= this.wData.interval)
            {
                BulletGenerate();
                this.wData.deltaTime = 0.0f;
            }
            else
            {
                this.wData.deltaTime += Time.deltaTime;
            }
        }
        else if (ScreenTouch.touchState == TouchPhase.Ended)
        {
            this.wData.deltaTime = 0.0f;
        }
    }
    //-------------------------------------------------
}
