﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioBGM : MonoBehaviour
{
    private AudioSource Source;                  //オーディオソース
    public AudioClip[] clips;                   //音源

    void Start()
    {
        Source = GetComponent<AudioSource>();
        Source.loop = true;
    }

    public void AudioBGMSet(int SoundNum, float Vol)//BGM再生用関数(再生したい音源番号,ボリューム 0.0f～1.0f)
    {
        Source.Stop();
        Source.clip     = this.clips[SoundNum];
        Source.volume   = Vol;                        //ボリューム
        Source.Play();                              //音源再生

        Debug.Log("BGM変更：" + SoundNum);
    }
    public void AudioBGMUnLoop()                    //BGMループ解除関数
    {
        Source.loop = false;
    }
}
/*
　 実装方法
  このスクリプトは空objectにつけてください。

  AudioBGMObj = GameObject.FindGameObjectWithTag("BGMManager");//BGMManager検索
  上記をStart設定し、音源を生成したい場所に
  AudioBGMObj.GetComponent<AudioBGM>().AudioBGMSet(1, 1.0f);
*/
