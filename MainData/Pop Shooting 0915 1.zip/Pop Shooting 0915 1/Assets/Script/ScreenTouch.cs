﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------
/// <summary>
/// 左右どちらか
/// </summary>
public enum AngleLR { Left, Right };
//-------------------------------------------------
/// <summary>
/// スクリーンのタッチ関連
/// </summary>
public class ScreenTouch : MonoBehaviour
{
    /// <summary>
    /// //タッチしたか
    /// </summary>
    public static bool isTouch;
    /// <summary>
    /// タッチの状態
    /// </summary>
    public static TouchPhase touchState;
    /// <summary>
    /// タッチポジション
    /// </summary>
    public static Vector3 touchPos;
    /// <summary>
    /// 入力されたクリックの種類
    /// </summary>
    public static AngleLR touchLR;
    /// <summary>
    /// エフェクト生成クラス
    /// </summary>
    [SerializeField] ParticleGenerator pGenerator = null;
    //-------------------------------------------------
    void Start()
    {

    }

    void Update()
    {
        TouchUpdate();

        //タッチしたところに波紋生成
        if(isTouch && touchLR == AngleLR.Left && touchState == TouchPhase.Began)
        {
            this.pGenerator.Ripple(Camera.main.ScreenToWorldPoint(touchPos));
        }

    }
    //-------------------------------------------------
    /// <summary>
    /// タッチ関連の更新
    /// </summary>
    public void TouchUpdate()
    {
        //左クリック
        //押した瞬間
        if (Input.GetMouseButtonDown(0))
        {
            ScreenTouch.touchState = TouchPhase.Began;
            ScreenTouch.touchLR = AngleLR.Left;
            Debug.Log("押した瞬間：左");
        }
        //離した瞬間
        else if (Input.GetMouseButtonUp(0))
        {
            ScreenTouch.touchState = TouchPhase.Ended;
            ScreenTouch.touchLR = AngleLR.Left;
            Debug.Log("離した瞬間：左");
        }
        //押している間
        else if (Input.GetMouseButton(0))
        {
            ScreenTouch.touchState = TouchPhase.Moved;
            ScreenTouch.touchLR = AngleLR.Left;
            Debug.Log("押している間：左");
        }

        //左クリック
        //押した瞬間
        else if (Input.GetMouseButtonDown(1))
        {
            ScreenTouch.touchState = TouchPhase.Began;
            ScreenTouch.touchLR = AngleLR.Right;
            Debug.Log("押した瞬間：右");
        }
        //離した瞬間
        else if (Input.GetMouseButtonUp(1))
        {
            ScreenTouch.touchState = TouchPhase.Ended;
            ScreenTouch.touchLR = AngleLR.Right;
            Debug.Log("離した瞬間：右");
        }
        //押している間
        else if (Input.GetMouseButton(1))
        {
            ScreenTouch.touchState = TouchPhase.Moved;
            ScreenTouch.touchLR = AngleLR.Right;
            Debug.Log("押している間：右");
        }

        //入力ナシの場合
        else
        {
            ScreenTouch.isTouch = false;

            //処理終了
            return;
        }

        //入力があった場合
        {
            ScreenTouch.isTouch = true;
            //座標取得
            ScreenTouch.touchPos = Input.mousePosition;
        }
    }
    //--------------------------------------------------------------------------

}
