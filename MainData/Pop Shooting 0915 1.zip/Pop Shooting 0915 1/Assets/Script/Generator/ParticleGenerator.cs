﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParticleGenerator : MonoBehaviour
{
    public GameObject damagedParticle; //爆発エフェクト
    public GameObject rippleParticle; //波紋エフェクト
    public GameObject smokeParticle;   //煙エフェクト


    //爆発エフェクト生成
    public void Damaged(Vector3 pos_)
    {
        Instantiate(damagedParticle, pos_, Quaternion.identity);
    }

    //波紋エフェクト生成
    public void Ripple(Vector3 pos_)
    {
        Instantiate(rippleParticle, pos_, Quaternion.identity);
    }

    //煙エフェクト生成
    public void Smoke(Vector3 pos_)
    {
        Instantiate(smokeParticle, pos_, Quaternion.identity);
    }
}
