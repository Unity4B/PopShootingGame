﻿using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------
/// <summary>
/// ハンドガン
/// </summary>
public class HundGun : Weapon
{
	//フィールド
	/// <summary>
	/// 射撃可能か
	/// </summary>
	bool isShotPossible;
	//-------------------------------------------------
	public override void Awake()
	{
		base.Awake();
		this.wData.SetWeaponType(WeaponType.HundGun);
		this.isShotPossible = true;

		//サイズ調整
		transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
		transform.Rotate(new Vector3(265.0f, 270.0f, 0.0f));
	}

	void Update()
	{
		//射撃間隔を確認
		if (this.wData.deltaTime >= this.wData.interval || this.isShotPossible)
		{
			//射撃可能に
			this.isShotPossible = true;
			this.wData.deltaTime = 0.0f;
		}
		else
		{
			//時間計測
			this.wData.deltaTime += Time.deltaTime;
		}

	}
	//-------------------------------------------------
	//射撃処理
	public override void Shot()
	{
		//射撃可能でなければ処理せず
		if (!this.isShotPossible) { return; }

		//マウス入力状態に応じて
		if (ScreenTouch.touchState == TouchPhase.Began)
		{
			BulletGenerate();
			//SE
			this.seClass.AudioSESet(4, 0.4f);
			this.isShotPossible = false;
		}

	}
	//-------------------------------------------------
}
