﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WeaponSelectManager : MonoBehaviour
{
    public GameObject optionCanvas;
    public OptionManager optionManager;
    public Text weaponText;

    /// <summary>
    /// SEクラス
    /// </summary>
    AudioSE seClass = null;
	// Start is called before the first frame update
	void Start()
	{
        //optionCanvas = GameObject.Find("WeaponSelect").transform.Find("OptionCanvas").gameObject;
        //optionManager = optionCanvas.GetComponent<OptionManager>();

        this.seClass = GameObject.FindObjectOfType<AudioSE>();
	}

	public void OnbuttonDown_HandGun()
    {
        optionCanvas.SetActive(true);

        //武器情報セット　柄子
        WeaponGenerator.weaponDatas[this.optionManager.buttonNum].SetWeaponType(WeaponType.HundGun);

        optionManager.clickButton.GetComponentInChildren<Text>().text = WeaponGenerator.weaponDatas[this.optionManager.buttonNum].WName;

        //SE
        this.seClass.AudioSESet(2, 0.5f);

        gameObject.SetActive(false);
    }
    public void OnbuttonDown_ShotGun()
    {
        optionCanvas.SetActive(true);

        //武器情報セット　柄子
        WeaponGenerator.weaponDatas[this.optionManager.buttonNum].SetWeaponType(WeaponType.ShotGun);

        optionManager.clickButton.GetComponentInChildren<Text>().text = WeaponGenerator.weaponDatas[this.optionManager.buttonNum].WName;

        //SE
        this.seClass.AudioSESet(2, 0.5f);

        gameObject.SetActive(false);
    }
    public void OnbuttonDown_AssaultGun()
    {
        optionCanvas.SetActive(true);

        //武器情報セット　柄子
        WeaponGenerator.weaponDatas[this.optionManager.buttonNum].SetWeaponType(WeaponType.AssaultGun);

        optionManager.clickButton.GetComponentInChildren<Text>().text = WeaponGenerator.weaponDatas[this.optionManager.buttonNum].WName;

        //SE
        this.seClass.AudioSESet(2, 0.5f);

        gameObject.SetActive(false);
    }
    public void OnbuttonDown_RocketLauncher()
    {
        optionCanvas.SetActive(true);
        optionManager.clickButton.GetComponentInChildren<Text>().text = "ロケットランチャー";
        gameObject.SetActive(false);
    }
    public void OnbuttonDown_Sniper()
    {
        optionCanvas.SetActive(true);
        optionManager.clickButton.GetComponentInChildren<Text>().text = "スナイパー";
        gameObject.SetActive(false);
    }
    public void OnbuttonDown_Exit()
    {
        //SE
        this.seClass.AudioSESet(1, 0.5f);

        optionCanvas.SetActive(true);
        gameObject.SetActive(false);
    }
}
