﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// プレイヤー
/// </summary>
public class Player : Chara
{
    //フィールド
    /// <summary>
    /// 初期クォータニオン
    /// </summary>
    Quaternion sQuaternion;
    /// <summary>
    /// 装備武器
    /// </summary>
    public GameObject weapon;
    /// <summary>
    /// 装備している武器番号
    /// </summary>
    int weaponNum;
    //-------------------------------------------------
    void Start()
    {
        this.charaParam = new Param(Camera.main.transform.rotation.y, 0, 0, 2.0f, Param.Status.Move);
        this.sQuaternion = transform.rotation;
        this.weaponNum = 0;
        this.weapon = transform.GetChild(this.weaponNum).gameObject;
    }

    void Update()
    {
        Move();

        //マウス入力時のみ処理
        if (ScreenTouch.isTouch)
        {
            if (Input.GetMouseButton(0))
            {
                Attack();
            }

            if (Input.GetMouseButtonDown(1))
            {
                WeaponChange();
            }
        }

    }
    //-------------------------------------------------
    /// <summary>
    /// 武器切り替え
    /// </summary>
    void WeaponChange()
    {
        this.weaponNum++;
        this.weaponNum %= 2;

        this.weapon = transform.GetChild(this.weaponNum).gameObject;

        Debug.Log("武器切り替えをしました。");
    }
    //-------------------------------------------------
    public override void Attack()
    {
        //攻撃
        this.weapon.GetComponent<Weapon>().Shot();
    }
    //-------------------------------------------------
    public override void Hit(int damage_)
    {
        //当たり判定の後の処理
        this.charaParam.life -= damage_;
    }
    //-------------------------------------------------
    public override void Move()
    {
        //動き
        switch (this.charaParam.status)
        {
            case Param.Status.Waiting:   //待機中の処理
                WaitingUpdate();
                break;
            case Param.Status.Attack: //攻撃中の処理
                AttackUpdate();
                break;
            case Param.Status.Move:   //動いている間の処理
                MoveUpdate();
                break;
            case Param.Status.Hit:    //被弾中の処理
                HitUpdate();
                break;
        }

    }
    //-------------------------------------------------
    public override void Anim()
    {
        //アニメーション
        switch (this.charaParam.status)
        {
            case Param.Status.Waiting:   //待機中のアニメーション
                WaitingAnim();
                break;
            case Param.Status.Attack: //攻撃中のアニメーション
                AttackAnim();
                break;
            case Param.Status.Move:   //動いている間のアニメーション
                MoveAnim();
                break;
            case Param.Status.Hit:    //被弾中のアニメーション
                HitAnim();
                break;
        }
    }
    //-------------------------------------------------
    public override void WaitingUpdate()
    {
        //待機中の処理
    }
    //-------------------------------------------------
    public override void AttackUpdate()
    {
        //攻撃中の処理
    }
    //-------------------------------------------------
    public override void MoveUpdate()
    {
        //動いている間の処理

        //カメラの向きにプレイヤーの向きを合わせる
        float y = Camera.main.transform.rotation.eulerAngles.y - transform.rotation.eulerAngles.y;
        transform.Rotate(new Vector3(0.0f, y, 0.0f), Space.World);
    }
    //-------------------------------------------------
    public override void HitUpdate()
    {
        //被弾中の処理

    }
    //-------------------------------------------------
    public override void WaitingAnim()
    {
        //待機中のアニメーション
    }
    //-------------------------------------------------
    public override void AttackAnim()
    {
        //攻撃中のアニメーション
    }
    //-------------------------------------------------
    public override void MoveAnim()
    {
        //動いている間のアニメーション
    }
    //-------------------------------------------------
    public override void HitAnim()
    {
        //被弾中のアニメーション

    }
    //-------------------------------------------------
}
