﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chara : MonoBehaviour
{
	public struct Param
	{
		public float Angle;      //Xの角度       
		public int maxlife;      //最大体力
		public int life;         //現在体力
		public int weapon;       //武器
		public float movespeed;  //動くスピード
		public enum Status       //状態
		{
			Waiting,             //待機
			Attack,              //攻撃
			Move,                //移動 
			Hit                  //被弾
		}
		public Status status;
		public Param(float Angle_,int life_, int weapon_, float speed_, Status status_)
		{
			//初期化
			
			this.Angle = Angle_;
			this.maxlife = life_;
			this.life = life_;
			this.weapon = weapon_;
			this.movespeed = speed_;
			this.status = status_;
		}
	}

	public Param charaParam;

	public Chara()
	{
		this.charaParam = new Param(0.0f, 0, 0, 0.0f, Param.Status.Waiting);
	}
	public virtual void Attack()
	{
		//攻撃
	}
	public virtual void Hit(int damage_)
	{
		//当たり判定の後の処理
		this.charaParam.life -= damage_;
	}
	public virtual void Move()
	{
		//動き
		switch (this.charaParam.status)
		{
			case Param.Status.Waiting:   //待機中の処理
				WaitingUpdate();
				break;
			case Param.Status.Attack: //攻撃中の処理
				AttackUpdate();
				break;
			case Param.Status.Move:   //動いている間の処理
				MoveUpdate();
				break;
			case Param.Status.Hit:    //被弾中の処理
				HitUpdate();
				break;
		}

	}
	public virtual void Anim()
	{
		//アニメーション
		switch (this.charaParam.status)
		{
			case Param.Status.Waiting:   //待機中のアニメーション
				WaitingAnim();
				break;
			case Param.Status.Attack: //攻撃中のアニメーション
				AttackAnim();
				break;
			case Param.Status.Move:   //動いている間のアニメーション
				MoveAnim();
				break;
			case Param.Status.Hit:    //被弾中のアニメーション
				HitAnim();
				break;
		}
	}
	public virtual void WaitingUpdate()
	{
		//待機中の処理
	}
	public virtual void AttackUpdate()
	{
		//攻撃中の処理
	}
	public virtual void MoveUpdate()
	{
		//動いている間の処理
	}
	public virtual void HitUpdate()
	{
		//被弾中の処理

	}
	public virtual void WaitingAnim()
	{
		//待機中のアニメーション
	}
	public virtual void AttackAnim()
	{
		//攻撃中のアニメーション
	}
	public virtual void MoveAnim()
	{
		//動いている間のアニメーション
	}
	public virtual void HitAnim()
	{
		//被弾中のアニメーション

	}
}
