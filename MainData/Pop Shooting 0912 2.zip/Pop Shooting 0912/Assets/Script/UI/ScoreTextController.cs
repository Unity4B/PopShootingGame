﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//UI:スコア表示テキスト
public class ScoreTextController : MonoBehaviour
{
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
