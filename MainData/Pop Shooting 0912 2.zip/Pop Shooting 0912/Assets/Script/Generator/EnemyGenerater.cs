﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyGenerater : MonoBehaviour
{
    //ファイルから読み込む敵データ
    public struct EnemyData
	{
        public int SpawnRate;       //出現までのフレーム数
        public int EnemyType;       //敵の種類の番号
        public int PositionNumber;  //敵の出現位置の配列番号
	}
    //敵データ格納配列
    public List<EnemyData> eds = new List<EnemyData>();
    //敵の種類
    [SerializeField] GameObject[] EnemyPrefabs = new GameObject[] { };
    //敵の出現位置
    Vector3[] SpawnPositions;

    //フレームカウント用
    int NowFlame;

    //現在のウェーブ数
    int NowWave;
    //前フレームのウェーブ数
    int PreWave;
    // Start is called before the first frame update
    void Start()
    { 
        //変数初期化
        NowFlame = 0;
        NowWave = 0;
        PreWave = NowWave;

        //出現位置設定（現在テスト用のみ格納）
        SpawnPositions = new Vector3[] {
            new Vector3(-53,13,-9),     //テスト0
            new Vector3(35,13,-39),    //テスト1
            new Vector3(35,13,40),   //テスト2
        };
        
        //最初のウェーブ読み込み（仮置き）
        ReadEnemyFile read = GetComponent<ReadEnemyFile>();
        eds = read.ReadFile_EnemyData("Wave" + NowWave + ".txt");
    }

    // Update is called once per frame
    void Update()
    {
        //現在のウェーブ数を取得（0仮置き）
        NowWave = 0;
        //ウェーブチェンジ時にテキストファイルを読み込む
        if (Check_ChengeWave())
        {
            eds.Clear();
            ReadEnemyFile read = GetComponent<ReadEnemyFile>();
            eds = read.ReadFile_EnemyData("Wave" + NowWave + ".txt");
            NowFlame = 0;
            PreWave = NowWave;
        }
        //フレーム数に応じて敵を出現させる
        for (int i = 0; i < eds.Count; i++)
        {
            if (eds[i].SpawnRate == NowFlame)
            {
                GameObject Enemy;
                Enemy = Instantiate(EnemyPrefabs[eds[i].EnemyType]);
                Enemy.transform.position = SpawnPositions[eds[i].PositionNumber];
                //(Clone)←消す
                Enemy.name = EnemyPrefabs[eds[i].EnemyType].name;
            }
        }
        NowFlame++;
    }
    //ウェーブの変更をチェック
    bool Check_ChengeWave()
	{
        //現在のフレームが前のフレームと違ったらtrue
        if(PreWave!=NowWave)
        {
            return true;
        }
        return false;
	}
}
