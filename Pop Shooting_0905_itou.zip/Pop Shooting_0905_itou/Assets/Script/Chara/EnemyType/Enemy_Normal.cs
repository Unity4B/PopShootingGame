﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Normal : MonoBehaviour
{
    public int HP = 10;
    public float movespeed = 0.1f;
    public int Power = 2;
    public float HitPower = 0.01f;

    public int enemyHP()
    {
        return HP;
    }
    public float moveSpeed()
    {
        return movespeed;
    }
    public int damege()
    {
        return Power;
    }
    public float knockback()
    {
        return HitPower;
    }
}
