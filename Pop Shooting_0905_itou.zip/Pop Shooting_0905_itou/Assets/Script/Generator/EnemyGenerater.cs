﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyGenerater : MonoBehaviour
{
    //ファイルから読み込む敵データ
    public struct EnemyData
	{
        public int SpawnRate;       //出現までのフレーム数
        public int EnemyType;       //敵の種類の番号
        public int PositionNumber;  //敵の出現位置の配列番号
	}
    //敵データ格納配列
    public List<EnemyData> eds = new List<EnemyData>();
    //敵の種類
    [SerializeField] GameObject[] EnemyPrefabs = new GameObject[] { };
    //敵の出現位置
    [SerializeField] Vector3[] SpawnPositions = new Vector3[] { };

    //フレームカウント用
    int NowFlame = 0;
    // Start is called before the first frame update
    void Start()
    {
        //テスト用位置
        SpawnPositions[0] = new Vector3(0, 0, 0);
        SpawnPositions[1] = new Vector3(10, 0, 0);
        SpawnPositions[2] = new Vector3(-10, 0, 0);

        ReadEnemyFile read = new ReadEnemyFile();
        eds = read.ReadFile_EnemyData("EnemyTest.txt");
        NowFlame = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if (Check_ChengeWave())
        {
            ReadEnemyFile read = new ReadEnemyFile();
            eds = read.ReadFile_EnemyData("EnemyTest.txt");
            NowFlame = 0;
        }
        while (NowFlame == eds[0].SpawnRate)
        {
            GameObject Enemy;
            Enemy = Instantiate(EnemyPrefabs[eds[0].EnemyType]);
            Enemy.transform.position = SpawnPositions[eds[0].PositionNumber];
            eds.RemoveAt(1);
        }
        NowFlame++;
    }
    bool Check_ChengeWave()
	{
        return false;
	}
}
