﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//-------------------------------------------------
/// <summary>
/// シーン切り替え
/// </summary>
public class SceneChangeController : MonoBehaviour
{
    //フィールド
    /// <summary>
    /// 動作中か
    /// </summary>
    bool isRunning;
    //-------------------------------------------------
    void Start()
    {
        this.isRunning = false;
    }
    //-------------------------------------------------
    /// <summary>
    /// シーン切り替え
    /// </summary>
    /// <param name="sName">次のシーン名</param>
    public void SceneChange(string sName)
    {
        //既に切り替え中の場合、処理しない
        if (this.isRunning) { return; }

        this.isRunning = true;

        SceneManager.LoadScene(sName);

        Debug.Log("シーン切り替え：" + sName);
    }
    //-------------------------------------------------
}
